from flask import Flask
from config import config
from app.extensions import db, migrate


def create_app(config_name='production'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # 初始化扩展
    db.init_app(app)
    migrate.init_app(app, db)

    # 注册蓝图
    from app.routes.deduction import bp as deduction_bp
    app.register_blueprint(deduction_bp)

    # 生产环境健康检查
    @app.route('/health')
    def health_check():
        return 'OK'

    return app
